======================================================================

Map Title                : mp_uo_dufresne_winter
Map Version              : UO
Author                   : -HG- Baby Seal Clubber
E-mail                   : zenguitar99@yahoo.com

----------------------------------------------------------------------

Call of Duty: United Offensive

Gametypes
                         : Deathmatch
                         : Team Deathmatch
                         : Capture the Flag
                         : Behind Enemy Lines
                         : Headquarters
                         : Retrieval
                         : Search and Destroy
			 : Domination

----------------------------------------------------------------------

Installation Instructions:
	Put "z_mp_uo_dufresne_winter.pk3" inside your UO folder.

----------------------------------------------------------------------

Filbert:
Almost a year ago -HG- Baby Seal Clubber was kind enough to give me the 
.map files for dufresne.  The idea was to adapt both versions to the 
Other Fronts mod, makeing the map Russian vs. Finnish.  Since the mod 
never was completed I didn't get around to the summer version. I took 
the winter version, though, and added CTF and DOM, fixed some lighting 
issues, and added new things such as opening some buildings.  Well this 
has been sitting around for awhile so I thought I'd release it.

----------------------------------------------------------------------

The flags in CTF and DOM as well as the victory image for the Axis are 
still Finnish, left over from the mod.  I didn't pull them out because 
they don't seem to be hurting anything.
