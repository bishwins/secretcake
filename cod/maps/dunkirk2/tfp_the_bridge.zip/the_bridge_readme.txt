The Bridge (A Medal Of Honor conversion)- the_bridge.pk3

=====================================================

--MAP INFORMATION--

Title:                    The Bridge
Version:                  Initial Release.
Filename:                 the_bridge.bsp
Created By:               [tFp] CFH666
Author Email:             cfh666@thefiberpipe.com
Supported Gametypes:      DM, HQ, SD, TDM
Description:              Conversion of The Bridge from MOHAA.
Web:                      http://www.thefiberpipe.com
Compile Date:             9-5-04

======================================================

--NOTES--

This is my first map I have ever done(converted). I know THE BRIDGE has been converted several times by others,
but I started way back when radiant was first released just to learn how to use the editor. I had no
intention to ever finishing or releasing it.

I take no credit for the design of the map as credit goes to 2015 for making the map as well as MOH.
I did not change anything to affect gameplay but I have added a lot more detail then what was originally
incorporated in the original map.

======================================================

--COMPILER SETTINGS--

-VIS-
	Fast

-FLARE-
	Extra
	ModelShadow
	ModelAlphaShadow
	sundiffusesamples 10

-WORLD SPAWN VALUES-
	"_color" "1 1 1"
	"ambient" ".085"
	"spawnflags" "256"
	"diffusefraction" ".2"
	"sundiffusecolor" "1 1 1"
	"sundirection" "-24 230 0"
	"suncolor" "1 1 1"
	"sunlight" "1.7"
	
======================================================

--CHANGES / REVISIONS--

This is the initial release. If there are bugs, or exploits, e-mail me at the above address
or send me some private messages on either www.iwnation.com Forums, or [tFp] forums at 
www.thefiberpipe.com. Make sure to provide screenshots, PREFERABLY DEMOS of the exploit.

======================================================

--THANKS TO--

[tFp] Daryl Strawberry aka OJ Kenobi for having the patients to show me how to use radiant
and helping me out over TeamSpeak... Thank you, you no good god damn dirty yankee :D.

Wyatt Earp for his tutorials as well as answering many questions.

The mapping community of www.iwnation.com's forums.

[tFp] Clan for spending much time just running around looking for glitches/etc. and for 
suggestions.

======================================================

--INSTALLATION--

Extract(if inside a .zip) or copy THE_BRIDGE.PK3 to the PROGRAM FILES\CALL OF DUTY\MAIN folder.

======================================================
�2004 [tFp] CFH666
