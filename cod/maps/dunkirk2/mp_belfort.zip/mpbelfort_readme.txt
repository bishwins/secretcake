MP_Belfort readme!

Thanks for downloading my map.  This is my 2nd try at mapping and I think
it turned out pretty good.  The map is set in a mountain area between occupied France
and the Swiss border.  The map takes place in a forrested canyon pass with multiple
German checkpoints and a German supply depot in the middle.  American troops oppose 
the Germans for control of the area.

INSTALLATION

Put the mp_belfort.pk3 file in the Call of Duty\main folder.
That is it!  

GAME TYPES SUPPORTED

DM  - 27 spawns
TDM - 63 spawns
BEL - 27 spawns
HQ  - 63 spawns
RE  - 32 spawns

SPECIAL THANKS

[AWE]Tally for the encouragement and for naming the dang thing!
Wyatt Earp for the excellent tutorials and the email answers to questions
The staff and forum community at MODSONLINE for their assistance
The staff and community at Electronic Warfare for playtesting
Clan FSG for the play testing and custom map night
Clan ACS for their play testing and hosting of the map

DISCLAIMER

As stated above this is my 2nd attempt at mapping and my first one to actually be released.
There may be bugs or errors despite my efforts to eliminate them.  Please feel free to send
me the ones that you find.  If there are enough to warrant another compile I will fix and 
re-release the map.

CONTACT

ZDogJones - Catch me online
zdogjones - YIM
zdogjones - AIM
41335256  - ICQ

zdogjones@yahoo.com - email
www.zdoghouse.net is my website.

ENJOY!

Z