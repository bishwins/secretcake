======================================================================

Map Title                : Brecourt manor
Map Version              : Ver 1.0
Author                   : Starlight
E-mail                   : starlight@dreamrealitystudios.co.uk
Website                  : http://www.dreamrealitystudios.co.uk

======================================================================

Game                     : CODUO

Supported Gametype       : Multiplayer
                         : Deathmatch
                         : Team Deathmatch
                         : Capture the Flag
                         : Behind Enemy Lines
                         : Headquarters
                         : Retrieval
                         : Search and Destroy
                         : Other
Domination, Capture The Flag
Map Size                 : 20-up : Very Large

======================================================================

Contents of this Package :

     pk3 file containing :-
     
     Arena File
     bsp File
     gsc File
     Sounds for vehicles
     Level shot
     
     and :-
     
     Readme File
     Original map File
     

======================================================================

Installation Instructions:

     Place the pk3 file in your Call of Duty Main folder and
     enjoy :)

======================================================================

Construction Time        : Evenings and weekends over a three month period

Custom Content           : 
Known Bugs               : Some of the Headquarters Radios are not
                           facing in right direction, due to a lack of
                           time for testing to get them all correct

======================================================================

Credit to Other Authors  :

     Original COD map creators for the Brecourt Area maps, from
     which this inspiration was created.  

======================================================================

Special Thanks           :

     To all those at Modsonline who gave assistance in the forums
     and to the various tutorials which helped this author a
     great deal.

======================================================================

Additional Notes         :

     Unfortunately, due to a lack of time and potentially HUGE
     compile times the extended version of this map has been
     delayed until a later stage, where the actual outlying
     fields and guns will be added, making this a Very Large Map.

======================================================================

This readme file was generated at MODSonline.com

Visit MODSonline.com for custom game content:
     Downloads, Projects, Forums, Tutorials, Videos, Reviews, News, etc.

http://www.modsonline.com/            January 30, 2005