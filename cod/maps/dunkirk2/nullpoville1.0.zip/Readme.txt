Nullpoville(1.0)

This map is a river side city. 

And,there are a Great church, City Hall, and some streets, two tanks. 

Maybe, this map is advantageous for the sniper. 

But, tanks will decrease the advantage. 

Changes:
Fixed all known bugs with Nullpoville.
I added some models and anti tank weapons and special weapon(it is secret!).

Hint of secret room:

Black pillar and Purple light

Gametype:

dm tdm sd ctf dom

Installation:

unpack the pk3 file to you ~\Call of Duty\Main folder.

Uninstallation:

remove pk3 from your ~\Call of Duty\Main folder.

By S.P.Q.R.
E-Mail sakugyousoh@hotmail.com 