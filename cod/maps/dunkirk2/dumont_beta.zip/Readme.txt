-=-=-=-=-=-=-=-	
Dumound_beta_8
-=-=-=-=-=-=-=-

-_-_-_-_-_-_-
Info:

Author: -=+[DTNL ZiggY]+=-
Mail:achtrs@gmail.com
Gametypes: DM,TDM,S&D
Players: 4-20+
[allies] = American
[axis] = german

_-_-_-_-_-_-
Notes for installation 

Place the Dumount_beta_8.pk3 in you Program files/Call of duty/uo

_-_-_-_-_-_-
Thanks to:

-=+[DTNL Clan]+=- - For playing and hosting.


_-_-_-_-_-_-
-=+[DTNL Clan]+=-| - Check us out @  www.dtnlclan.tk


Happy playing!
