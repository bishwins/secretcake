Please read.

Map name		: Bootcamp
Status			: Final
Game types	:DM & TDM
Players			: 30
Game ver		: United Offensive Only (not tested under COD)

Hi there, this is final release version.
It is 100% complete and the gameplay is great. 
Please spread this map as far in your community as possible.

Installation Instructions: Unzip and place the pk3 in your C:\Program Files\Call of Duty\UO folder 

Any bugs or feedback reports can be sent to me at >  sgtdeath at gmail dot com


Thank you
[-IAG-]Sgt.DeAtH