=====================================================================
DM701 Multiplayer Map - Deathmatch � copyright 2004 A. Gasch K�hne
=====================================================================
			*** BETA Version ***
=====================================================================

Title                   : DM701_beta.zip 
BSP Name                : DM701.pk3
Author                  : DM701
Beta Release		: Feb 29, 2004
Release Date            : T.B.A.
E-mail Address          : dm701@callofdutyweb.com
Home Page               : www.xs4all.nl/~agk73/DM701.htm
Game                    : Call of Duty
Developer		: Infinity Ward
Publisher		: Activision 


=====================================================================

* HOW TO INSTALL THIS MAP *

1. USE WINZIP TO EXTRACT IT
2. COPY THE DM701.PK3 FILE TO YOUR [ ../Call of Duty/Main ] FOLDER   
3. RUN "CALL OF DUTY Multiplayer"
4. CHOOSE "DM701" from the map list  

=====================================================================

* MAP Information *

Beta release            : yes
New Textures            : yes

Suported Game Types     : DM
Player Count            : 4-32 players
Editor used             : CoDRadiant

=====================================================================

* Copyright / Permissions *

All original and composed textures in this level remain property of
the sources respective owners.
You may distribute this PK3 in any electronic format (BBS, Internet,
CD, etc) as long as you include all files intact in the
original archive accompanied by this Readme_DM701_beta.txt file. 

copyright 2004

=====================================================================

* Must Read and Understand Before Use *

The author of this file accepts no responsibility for damage to data,
or physical damage to hardware, caused by the appropriate or
inappropriate use of this file. It is deemed that users who run this
file, automatically are considered as having read and understood 
this liability clause before using the said file. 

=====================================================================