Install to your Call of Duty main Folder!

Created by Nash May 2004