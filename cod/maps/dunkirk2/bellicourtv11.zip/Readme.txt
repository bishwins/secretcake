--------------------------------
   B E L L I C O U R T   v1.1
--------------------------------

Design: Magnus Sandstr�m
Script: Roger Abrahamsson
Completed: 2004-03-02
Contact: magnus.s@syndnet.net

Gametypes: DM, TDM, SD, RT, BEL, HQ
Spawns: 64

To play just drop the .pk3 file in your "Call of Duty\Main" folder.


Fixed clipping issue where you could get outside the map.
Moved and added spawn points for RE and SD.
Added some bushes to block line of sight to retrieval delivery spot.
Removed/moved mg42 for SD




---------------
Though influenced by my favourite multi player map mp_carentan it developed into a completely unique map in the end. Many thanks to my mentor Roger for encouragement and support as well as adding all portals, scripts and special effects.

I you find any errors or problems feel free to contact me with suggestions for improvements.


Happy hunting

Magnus