mp_uo_crossraods

=====================================================

--MAP INFORMATION--

Title: mp_uo_crossroads
Version: 1.0
Filename: mp_uo_crossroads.bsp
Created By: [NNLAN]slater
Type: DM/TDM/SD/BE/RE/CTF/DOM/HQ
New Textures : no
Web: http://slater.no-ip.com/
Mail: coryteale@yahoo.ca
======================================================

This is my first atttempt at a Call of Duty map.  Hope you like it!  Took way to many hours to mention to build (learning curve mostly).  Supports all game types except Base Assault.

Install:

Place the mp_uo_crossroads.pk3 into your UO Folder.

To Un-install:

Just delete the mp_uo_crossroads.pk3 file