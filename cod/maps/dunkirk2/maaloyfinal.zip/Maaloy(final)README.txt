=========================
MAALOY (FINAL) (Call of Duty map)
=========================


CREATOR: [126th]Televinken


E-MAIL: tele.vinken@bredband.net


BUGFIXES: Fixed 2 map-exploits where u could get to places u shouldnt, texture-errors 

fixed, adjusted tdm-spawnpoints.


ABOUT THE MAP:

This is a historicaly inspired multiplayermap about a Brittish commandoraid in

Norway, december 27th, 1941.

After a successful operation in the Lofoten Islands the British Commandos together

with the Norwegian �Linge� company tried something more difficult, the attack on

M�l�y (Operation Archery). In contrast to the previous operation, the objectives 

was well defended by a German garrison and coastal batteries. 

Operation Archery is one of the most well known and certainly the best photographed 

as the raid was accompanied by official photographers and cameramen.

The Norwegian warhero Martin Linge was killed in this battle and he is featured in 

the gametype retrieval as one objective.


INSTALLATION INSTRUCTIONS:

Extract mp_maaloy.pk3 into your CallofDuty/main folder.


FILE INFO: 

Gametypes: DM TDM RE BEL SD and HQ

DM -spawnpoints: 64

TDM-spawnpoints: 64

RE -spawnpoints: 42

SD -spawnpoints: 42


SPECIAL THANKS TO:

[126th]Batten for loadingscreen and view-map pic, Cyion at IWN for finding the 2 map-

exploits, IW-NATION and .MAP for the mapforums, r0ger for noprone-script and the 

clans [126th], [NCMC] and >>DK<< for testing and feedback.


Hope you enjoy the map and see you on the battlefield!


PS: Stay out of the water, you cant prone/crouch and its REALLY cold ;-).