Fivepoints 
by 
BigBoyG 

Legal stuff: Just, like, be cool, dig?

- final release -

I n s t a l l a t i o n: 

Unzip the fivepoints.pk3 into your CallofDuty/main folder. The PK3 replaces any previous version you may have.

C o n s t r u c t i o n   d e t a i l s:

Entities: 		577

Spawn points: 		23 TDM 
			19 DM

Compile: 		FUll bsp 
			Full vis (0 blocks)
			Flare extra. 

Is there a better build for final compile? Let me know.

Custom shaders:		No, used the stypes included in the game

Custom textures: 	Yes, all in the folder textures/fivepoint

Compile time: 		45 mins. Detail brushes are your FRIEND.

T h e   m a p:

Gametypes: 		DM and TDM. Next one will have another gametype.

Setting: Very loosely based off the Fivepoints area in New York (Gangs of New York). I kind of lost that inspiration halfway through, but you'll still see some elements in there. It's a foggy autumn night. Everything is dying. Including you.

T h a n k s:

Many thanks to all at IW for a fantastic game and for supporting their fans with a quick editor release, and to General Death, ScorpioMidget, Snake Shift and various other members of the mapping community for the help, tutorials and quick responses.

Thanks to TheStorm for the kick ass builder. Get the VClog option working, dammit!

Also thanks to Kalti at www.uberclan.com for being the first to host the map, and to any others that may host it afterwards.

Final release thanks: Gilvo -X- and P.O.S -X- for testing out the map and giving me some great gameplay feedback, plus they found a few bugs too!

I'd also like to thank the academy. When Harvey first approached me with the role of...

BBG

C o n t a c t:

bigboyg@sbcglobal.net

I welcome ANY and ALL feedback. If you don't like the way part of the map plays, let me know so I can make the next one better.
