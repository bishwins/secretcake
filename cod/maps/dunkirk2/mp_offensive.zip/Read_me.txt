mp_offensive finale

Design by Old-Crow 
Mods/Fx/optimisation by Caskou 

final Version (sd - re - tdm - dm - bel - hq):

- Search And Destroy : 16 vs 16
- Retrieval : 16 vs 16
- Team Death Match : 16 vs 16
- Behind Ennemy Line : 32 players
- Death Match : 32 players
- HeadQuarter : 32 players

Just put mp_offensive.pk3 in your /call of duty/main folder

Have Fun !!!

[SAD] old-Crow (www.spy-and-destroy)
[X MEn] Caskou (www.caskami.fr.st - www.clanXmen.com)

